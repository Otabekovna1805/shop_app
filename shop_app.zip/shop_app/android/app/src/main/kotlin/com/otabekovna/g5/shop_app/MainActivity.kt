package com.otabekovna.g5.shop_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
